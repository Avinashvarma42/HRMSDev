from sqlalchemy.orm import Session
from app.repositories.hostel_repository import HostelRepository
from app.models.booking import Booking
from datetime import datetime

def create_booking(db: Session, data):
    repo = HostelRepository(db)
    booking = Booking(
        hostel_id=data.hostel_id,
        visitor_name=data.visitor_name,
        visitor_email=data.visitor_email,
        visitor_phone=data.visitor_phone,
        check_in=data.check_in,
        check_out=data.check_out,
        notes=data.notes,
        status="pending",
        created_at=datetime.utcnow()
    )
    return repo.create_booking(booking)
