from sqlalchemy.orm import Session
from app.repositories.hostel_repository import HostelRepository
from app.models.review import Review

def create_review(db: Session, hostel_id: int, visitor_name: str, rating: int, comment: str):
    repo = HostelRepository(db)
    review = Review(hostel_id=hostel_id, visitor_name=visitor_name, rating=rating, comment=comment)
    return repo.add_review(review)

def list_reviews(db: Session, hostel_id: int):
    repo = HostelRepository(db)
    return repo.get_reviews(hostel_id)
