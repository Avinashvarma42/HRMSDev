import os
from typing import List
from fastapi import UploadFile
from uuid import uuid4

UPLOAD_ROOT = os.getenv("UPLOAD_ROOT", "uploads")

def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)

def save_hostel_photos(hostel_id: int, files: List[UploadFile]) -> List[str]:
    """
    Saves uploads locally under uploads/hostels/{hostel_id}/ and returns accessible URLs (path-like).
    Replace with S3 upload logic in production.
    """
    dest = os.path.join(UPLOAD_ROOT, "hostels", str(hostel_id))
    ensure_dir(dest)
    urls = []
    for f in files:
        ext = os.path.splitext(f.filename)[1] or ".jpg"
        fname = f"{uuid4().hex}{ext}"
        out_path = os.path.join(dest, fname)
        # write file
        with open(out_path, "wb") as buffer:
            buffer.write(f.file.read())
        # in production you would return CDN URL
        urls.append(f"/{out_path.replace(os.sep, '/')}")
    return urls


def presign_hostel_photo(hostel_id: int, filename: str, content_type: str | None = None) -> dict:
    """
    Return a presigned upload URL and a key for the uploaded file.

    For local development this returns a file-path-like URL and a key the caller
    can use to register the photo after upload. In production this should
    return an S3 presigned PUT URL and the object key.
    """
    ext = os.path.splitext(filename)[1] or ".jpg"
    key = f"hostels/{hostel_id}/{uuid4().hex}{ext}"
    # For local development we return a file:// URL where client can PUT the file
    # (clients may instead upload directly to an S3 URL in production).
    upload_path = os.path.join(UPLOAD_ROOT, key.replace("/", os.sep))
    ensure_dir(os.path.dirname(upload_path))
    upload_url = f"file://{os.path.abspath(upload_path)}"
    return {"upload_url": upload_url, "key": key}


