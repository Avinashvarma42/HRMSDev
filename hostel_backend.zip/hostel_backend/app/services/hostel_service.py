from typing import List, Optional
from sqlalchemy.orm import Session
from app.repositories.hostel_repository import HostelRepository
from app.models.hostel import Hostel
from app.schemas.hostel import HostelCreate, HostelUpdate

def public_list(db: Session, skip: int = 0, limit: int = 20, city: Optional[str] = None, q: Optional[str] = None, min_price: Optional[int] = None, max_price: Optional[int] = None, sort_by: Optional[str] = None):
    repo = HostelRepository(db)
    return repo.list(skip=skip, limit=limit, city=city, q=q, min_price=min_price, max_price=max_price, sort_by=sort_by)

def get_public_details(db: Session, hostel_id: int):
    repo = HostelRepository(db)
    hostel = repo.get(hostel_id)
    return hostel

def create_hostel_admin(db: Session, data: HostelCreate):
    repo = HostelRepository(db)
    hostel = Hostel(**data.dict())
    return repo.create(hostel)

def update_hostel_admin(db: Session, hostel_id: int, data: HostelUpdate):
    repo = HostelRepository(db)
    hostel = repo.get(hostel_id)
    if not hostel:
        return None
    return repo.update(hostel, data.dict(exclude_unset=True))
