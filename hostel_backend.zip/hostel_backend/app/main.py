from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.database import Base, engine, init_db
from app.api.v1.visitor import public, hostels as visitor_hostels, search, bookings as visitor_bookings, reviews as visitor_reviews
from app.api.v1.admin import hostels as admin_hostels

# create DB tables
init_db()

app = FastAPI(title="Hostel Management - Visitor Module")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(public.router, prefix="/api/v1/visitor/public", tags=["Visitor Public"])
app.include_router(visitor_hostels.router, prefix="/api/v1/visitor/hostels", tags=["Visitor Hostels"])
app.include_router(search.router, prefix="/api/v1/visitor/search", tags=["Visitor Search"])
app.include_router(visitor_bookings.router, prefix="/api/v1/visitor/bookings", tags=["Visitor Bookings"])
app.include_router(visitor_reviews.router, prefix="/api/v1/visitor/reviews", tags=["Visitor Reviews"])

# admin endpoints for managing hostel profiles & photos
app.include_router(admin_hostels.router, prefix="/api/v1/admin/hostels", tags=["Admin Hostels"])
