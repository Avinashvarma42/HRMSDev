"""
Database connection and session management
"""
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from app.config import settings

engine = create_engine(settings.DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """Database dependency"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Initialize database tables.

    This will import the app.models package so model classes are registered
    on `Base.metadata`, then create any missing tables.
    """
    # Import models package so that all modules defining models are imported
    # and their classes register with Base.metadata.
    try:
        import importlib

        importlib.import_module("app.models")
    except Exception:
        # If importing the package fails, continue; create_all will still work
        # for models that were imported elsewhere.
        pass

    Base.metadata.create_all(bind=engine)

