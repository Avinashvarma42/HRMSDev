from fastapi import Depends, HTTPException, Header
from sqlalchemy.orm import Session
from typing import Optional
from app.core.database import get_db

def get_db_dep():
    return Depends(get_db)

def admin_required(x_admin: Optional[str] = Header(None)):
    # Simple stub: pass header X-Admin: true to access admin endpoints.
    if x_admin and x_admin.lower() in ("1", "true", "yes"):
        return True
    raise HTTPException(status_code=403, detail="Admin credentials required")
