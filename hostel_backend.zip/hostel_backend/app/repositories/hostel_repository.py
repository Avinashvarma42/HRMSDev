from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models.hostel import Hostel, HostelPhoto
from app.models.review import Review
from app.models.booking import Booking

class HostelRepository:
    def __init__(self, db: Session):
        self.db = db

    def get(self, hostel_id: int) -> Optional[Hostel]:
        return self.db.query(Hostel).filter(Hostel.id == hostel_id).first()

    def list(self, skip: int = 0, limit: int = 20, city: Optional[str] = None, q: Optional[str] = None, min_price: Optional[int] = None, max_price: Optional[int] = None, amenities: Optional[List[str]] = None, sort_by: Optional[str] = None):
        query = self.db.query(Hostel).filter(Hostel.published == True)
        if city:
            query = query.filter(func.lower(Hostel.city) == city.lower())
        if q:
            query = query.filter(Hostel.name.ilike(f"%{q}%") | Hostel.description.ilike(f"%{q}%"))
        if min_price is not None:
            query = query.filter(Hostel.price_per_month >= min_price)
        if max_price is not None:
            query = query.filter(Hostel.price_per_month <= max_price)
        # sort_by sample: "price_asc", "price_desc", "recent"
        if sort_by == "price_asc":
            query = query.order_by(Hostel.price_per_month.asc())
        elif sort_by == "price_desc":
            query = query.order_by(Hostel.price_per_month.desc())
        else:
            query = query.order_by(Hostel.created_at.desc())
        return query.offset(skip).limit(limit).all()

    def create(self, hostel: Hostel):
        self.db.add(hostel)
        self.db.commit()
        self.db.refresh(hostel)
        return hostel

    def update(self, hostel: Hostel, data: dict):
        for k, v in data.items():
            setattr(hostel, k, v)
        self.db.add(hostel)
        self.db.commit()
        self.db.refresh(hostel)
        return hostel

    # Photo operations
    def add_photo(self, hostel_id: int, url: str, caption: str = None, order: int = 0) -> HostelPhoto:
        photo = HostelPhoto(hostel_id=hostel_id, url=url, caption=caption, order=order)
        self.db.add(photo)
        self.db.commit()
        self.db.refresh(photo)
        return photo

    def list_photos(self, hostel_id: int):
        return self.db.query(HostelPhoto).filter(HostelPhoto.hostel_id == hostel_id).order_by(HostelPhoto.order).all()

    def get_reviews(self, hostel_id: int):
        return self.db.query(Review).filter(Review.hostel_id == hostel_id).order_by(Review.created_at.desc()).all()

    def add_review(self, review: Review):
        self.db.add(review)
        self.db.commit()
        self.db.refresh(review)
        return review

    def create_booking(self, booking: Booking):
        self.db.add(booking)
        self.db.commit()
        self.db.refresh(booking)
        return booking
