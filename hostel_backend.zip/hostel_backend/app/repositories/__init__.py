# import repository classes for convenience
from .hostel_repository import HostelRepository
