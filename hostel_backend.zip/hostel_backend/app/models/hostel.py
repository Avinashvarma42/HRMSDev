from sqlalchemy import Column, Integer, String, Text, Boolean, Float, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from app.core.database import Base
import datetime

class Hostel(Base):
    __tablename__ = "hostels"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True, nullable=False)
    description = Column(Text, nullable=True)
    city = Column(String, index=True, nullable=True)
    address = Column(String, nullable=True)
    latitude = Column(Float, nullable=True)
    longitude = Column(Float, nullable=True)
    price_per_month = Column(Integer, nullable=True)
    published = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    photos = relationship("HostelPhoto", back_populates="hostel", cascade="all, delete-orphan")
    reviews = relationship("Review", back_populates="hostel", cascade="all, delete-orphan")

class HostelPhoto(Base):
    __tablename__ = "hostel_photos"
    id = Column(Integer, primary_key=True, index=True)
    hostel_id = Column(Integer, ForeignKey("hostels.id", ondelete="CASCADE"))
    url = Column(String, nullable=False)
    caption = Column(String, nullable=True)
    order = Column(Integer, default=0)

    hostel = relationship("Hostel", back_populates="photos")
