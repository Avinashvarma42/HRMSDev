from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel

class HostelPhotoOut(BaseModel):
    id: int
    url: str
    caption: Optional[str]
    order: int

    class Config:
        orm_mode = True

class HostelBase(BaseModel):
    name: str
    description: Optional[str]
    city: Optional[str]
    address: Optional[str]
    price_per_month: Optional[int]
    latitude: Optional[float]
    longitude: Optional[float]

class HostelCreate(HostelBase):
    pass

class HostelUpdate(BaseModel):
    name: Optional[str]
    description: Optional[str]
    city: Optional[str]
    address: Optional[str]
    price_per_month: Optional[int]
    published: Optional[bool]

class HostelOut(HostelBase):
    id: int
    published: bool
    created_at: datetime
    photos: List[HostelPhotoOut] = []

    class Config:
        orm_mode = True


class PhotoPresignRequest(BaseModel):
    filename: str
    content_type: Optional[str]


class PhotoPresignResponse(BaseModel):
    upload_url: str
    key: str

    class Config:
        orm_mode = True


class PhotoRegisterRequest(BaseModel):
    key: str
    caption: Optional[str] = None
    order: Optional[int] = 0

    class Config:
        orm_mode = True


