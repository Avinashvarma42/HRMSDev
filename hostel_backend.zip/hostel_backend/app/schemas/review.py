from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class ReviewCreate(BaseModel):
    visitor_name: Optional[str]
    rating: int
    comment: Optional[str]

class ReviewOut(BaseModel):
    id: int
    visitor_name: Optional[str]
    rating: int
    comment: Optional[str]
    created_at: datetime

    class Config:
        orm_mode = True
