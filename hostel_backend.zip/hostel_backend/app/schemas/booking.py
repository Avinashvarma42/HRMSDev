from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class BookingCreate(BaseModel):
    hostel_id: int
    visitor_name: str
    visitor_email: str
    visitor_phone: Optional[str]
    check_in: Optional[datetime]
    check_out: Optional[datetime]
    notes: Optional[str]

class BookingOut(BaseModel):
    id: int
    hostel_id: int
    visitor_name: str
    visitor_email: str
    visitor_phone: Optional[str]
    status: str
    created_at: datetime

    class Config:
        orm_mode = True
