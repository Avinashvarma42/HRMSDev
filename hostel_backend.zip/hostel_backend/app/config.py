from functools import lru_cache
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
	# Provide a sensible default so the app can import settings during development
	# without requiring an environment variable. Override in production via ENV or .env
	DATABASE_URL: str = Field("sqlite:///./test.db", env="DATABASE_URL")
	SECRET_KEY: str = Field("change-me", env="SECRET_KEY")
	ALGORITHM: str = Field("HS256", env="ALGORITHM")
	ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(30, env="ACCESS_TOKEN_EXPIRE_MINUTES")

	SMTP_HOST: str | None = Field(None, env="SMTP_HOST")
	SMTP_PORT: int | None = Field(None, env="SMTP_PORT")
	SMTP_USERNAME: str | None = Field(None, env="SMTP_USERNAME")
	SMTP_PASSWORD: str | None = Field(None, env="SMTP_PASSWORD")
	SMTP_FROM_EMAIL: str | None = Field(None, env="SMTP_FROM_EMAIL")
	SMTP_USE_TLS: bool = Field(True, env="SMTP_USE_TLS")

	DEBUG: bool = Field(False, env="DEBUG")

	model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")


@lru_cache()
def get_settings() -> Settings:
	return Settings()


# module-level singleton for convenience (used across the app)
settings = get_settings()

