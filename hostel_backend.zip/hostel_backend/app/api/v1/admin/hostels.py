from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from typing import List
from sqlalchemy.orm import Session
from app.schemas.hostel import HostelCreate, HostelOut, HostelUpdate
from app.schemas.hostel import PhotoRegisterRequest
from app.core.database import get_db
from app.dependencies import admin_required
from app.services import file_service
from app.services.hostel_service import create_hostel_admin, update_hostel_admin
from app.repositories.hostel_repository import HostelRepository

router = APIRouter()

@router.post("/", response_model=HostelOut, dependencies=[Depends(admin_required)])
def create_hostel(payload: HostelCreate, db: Session = Depends(get_db)):
    hostel = create_hostel_admin(db, payload)
    return hostel

@router.put("/{hostel_id}", response_model=HostelOut, dependencies=[Depends(admin_required)])
def update_hostel(hostel_id: int, payload: HostelUpdate, db: Session = Depends(get_db)):
    updated = update_hostel_admin(db, hostel_id, payload)
    if not updated:
        raise HTTPException(status_code=404, detail="Hostel not found")
    return updated

@router.post("/{hostel_id}/photos", dependencies=[Depends(admin_required)])
def upload_hostel_photos(hostel_id: int, files: List[UploadFile] = File(...), db: Session = Depends(get_db)):
    # ensure hostel exists
    repo = HostelRepository(db)
    hostel = repo.get(hostel_id)
    if not hostel:
        raise HTTPException(status_code=404, detail="Hostel not found")
    # save files via file service (local or S3)
    urls = file_service.save_hostel_photos(hostel_id, files)
    # add to DB
    photos = []
    for url in urls:
        photo = repo.add_photo(hostel_id, url)
        photos.append(photo)
    return {"uploaded": len(photos), "photos": [{"id": p.id, "url": p.url} for p in photos]}





@router.post("/{hostel_id}/photos/register", dependencies=[Depends(admin_required)])
def register_hostel_photo(hostel_id: int, payload: PhotoRegisterRequest, db: Session = Depends(get_db)):
    repo = HostelRepository(db)
    hostel = repo.get(hostel_id)
    if not hostel:
        raise HTTPException(status_code=404, detail="Hostel not found")

    # Build public URL from key and save record
    url = file_service.public_url_for_key(payload.key)
    photo = repo.add_photo(hostel_id, url, caption=payload.caption, order=payload.order or 0)
    return {"id": photo.id, "url": photo.url, "caption": photo.caption, "order": photo.order}
