from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.services.hostel_service import get_public_details
from app.schemas.hostel import HostelOut
from typing import List

router = APIRouter()

@router.get("/{hostel_id}", response_model=HostelOut)
def get_hostel(hostel_id: int, db: Session = Depends(get_db)):
    hostel = get_public_details(db, hostel_id)
    if not hostel:
        raise HTTPException(status_code=404, detail="Hostel not found")
    return hostel

@router.get("/{hostel_id}/photos")
def get_photos(hostel_id: int, db: Session = Depends(get_db)):
    from app.repositories.hostel_repository import HostelRepository
    repo = HostelRepository(db)
    return repo.list_photos(hostel_id)
