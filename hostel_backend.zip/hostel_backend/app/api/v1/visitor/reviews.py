from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.core.database import get_db
from app.schemas.review import ReviewCreate, ReviewOut
from app.services.review_service import create_review, list_reviews

router = APIRouter()

@router.post("/{hostel_id}", response_model=ReviewOut)
def post_review(hostel_id: int, payload: ReviewCreate, db: Session = Depends(get_db)):
    # ensure hostel exists
    from app.repositories.hostel_repository import HostelRepository
    repo = HostelRepository(db)
    if not repo.get(hostel_id):
        raise HTTPException(status_code=404, detail="Hostel not found")
    review = create_review(db, hostel_id=hostel_id, visitor_name=payload.visitor_name, rating=payload.rating, comment=payload.comment)
    return review

@router.get("/{hostel_id}", response_model=List[ReviewOut])
def get_reviews(hostel_id: int, db: Session = Depends(get_db)):
    return list_reviews(db, hostel_id)
