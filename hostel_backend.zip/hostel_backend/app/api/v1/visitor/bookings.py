from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.schemas.booking import BookingCreate, BookingOut
from app.services.booking_service import create_booking

router = APIRouter()

@router.post("/", response_model=BookingOut)
def create_visitor_booking(payload: BookingCreate, db: Session = Depends(get_db)):
    # verify hostel exists
    from app.repositories.hostel_repository import HostelRepository
    repo = HostelRepository(db)
    if not repo.get(payload.hostel_id):
        raise HTTPException(status_code=404, detail="Hostel not found")
    booking = create_booking(db, payload)
    return booking
