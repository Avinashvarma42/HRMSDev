from fastapi import APIRouter, Depends, Query
from typing import Optional, List
from sqlalchemy.orm import Session
from app.schemas.hostel import HostelOut
from app.schemas.hostel import HostelOut as HostelSchema
from app.core.database import get_db
from app.services.hostel_service import public_list

router = APIRouter()

@router.get("/hostels", response_model=List[HostelSchema])
def list_hostels(
    q: Optional[str] = Query(None, description="search term"),
    city: Optional[str] = Query(None),
    min_price: Optional[int] = Query(None),
    max_price: Optional[int] = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    sort_by: Optional[str] = Query(None, description="price_asc|price_desc|recent"),
    db: Session = Depends(get_db)
):
    return public_list(db, skip=skip, limit=limit, city=city, q=q, min_price=min_price, max_price=max_price, sort_by=sort_by)
