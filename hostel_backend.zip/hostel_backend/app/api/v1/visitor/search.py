from fastapi import APIRouter, Depends, Query
from typing import Optional, List
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.services.hostel_service import public_list
from app.schemas.hostel import HostelOut

router = APIRouter()

@router.get("/", response_model=List[HostelOut])
def search(
    q: Optional[str] = Query(None),
    city: Optional[str] = Query(None),
    min_price: Optional[int] = Query(None),
    max_price: Optional[int] = Query(None),
    skip: int = Query(0),
    limit: int = Query(20),
    db: Session = Depends(get_db)
):
    return public_list(db, skip=skip, limit=limit, city=city, q=q, min_price=min_price, max_price=max_price)
